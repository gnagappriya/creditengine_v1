package com.creditscore.engine.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
import com.creditscore.engine.repository.CreditScoreEngineRepository;

/*
 * Service to get the credit score from Repository
 */
@Service
public class CreditScoreEngineService {

	private final Logger logger = LoggerFactory.getLogger(CreditScoreEngineService.class);
	
	@Autowired
	CreditScoreEngineRepository creditScoreEngineRepository;
	/*
	 * The method calls the Repository to get credit score
	 * @param creditRequest
	 * @return creditScore
	 */
	public CreditScore getcreditScore(CreditRequest creditRequest) {
		logger.debug("CreditScoreEngineService : getcreditScore - creditRequest ", creditRequest);
		CreditScore creditScore = creditScoreEngineRepository.getCreditScore(creditRequest);
		logger.debug("CreditScoreEngineService : getcreditScore - creditScore ", creditScore);
		return creditScore;
	}
	public CreditScore savecreditScore(CreditScore creditScore) {
		creditScoreEngineRepository.saveCreditScore(creditScore);
		return null;
	}
}
