package com.creditscore.engine.pojo;

public class CreditRequest {
	
	private String ssnNumber;

	private Integer loanAmount;

	private Integer currentAnnualIncome;

	/**
	 * @return the ssnNumber
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}

	/**
	 * @param ssnNumber the ssnNumber to set
	 */
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}

	/**
	 * @return the loanAmount
	 */
	public Integer getLoanAmount() {
		return loanAmount;
	}

	/**
	 * @param loanAmount the loanAmount to set
	 */
	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * @return the currentAnnualIncome
	 */
	public Integer getCurrentAnnualIncome() {
		return currentAnnualIncome;
	}

	/**
	 * @param currentAnnualIncome the currentAnnualIncome to set
	 */
	public void setCurrentAnnualIncome(Integer currentAnnualIncome) {
		this.currentAnnualIncome = currentAnnualIncome;
	}
	
	
}
