package com.creditdecision.engine.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.creditdecision.engine.pojo.CreditRequest;
import com.creditdecision.engine.pojo.Response;
import com.creditdecision.engine.service.CreditDecisionEngineService;
/*
 * The service accepts credit request and calls credit score service and generate response
 */
@RestController
public class CreditDecisionEngineController {
	
	private final Logger logger = LoggerFactory.getLogger(CreditDecisionEngineController.class);
	
	@Autowired
	CreditDecisionEngineService creditDecisionEngineService;

	/*
	 * getCreditRequest send credit request and get Credit Score Response
	 * @param  creditReq
	 * @return creditScore
	 */
	@GetMapping("creditRequest")
	public ResponseEntity<Response> getCreditRequest(@RequestBody CreditRequest creditReq ) {
	logger.debug("CreditDecisionEngineController : getCreditRequest - starts ");
	logger.debug("getCreditRequest - CreditRequest ", creditReq);
	
	Response creditScore = creditDecisionEngineService.getcreditScore(creditReq);
	logger.debug("CreditDecisionEngineController : getCreditRequest - creditScore ",creditScore);
	logger.debug("CreditDecisionEngineController : getCreditRequest - end ");
	return  new ResponseEntity<Response>(creditScore,HttpStatus.OK);
}
}
