package com.creditdecision.engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditDecisionEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditDecisionEngineApplication.class, args);
	}

}
