package com.creditdecision.engine.service;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.creditdecision.engine.pojo.CreditRequest;
import com.creditdecision.engine.pojo.CreditScore;
import com.creditdecision.engine.pojo.Response;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CreditDecisionEngineService.class, RestTemplate.class })
class CreditDecisionEngineServiceTest {
	@Autowired
	CreditDecisionEngineService creditDecisionEngineService;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Mock
	RestTemplate restTemplate;

	@BeforeEach
	void setUp() throws Exception {
	}

	@Value("${url.name}")
	String urlName;

	@Test
	void testGetcreditScore() {
		Response creditScoreRes = creditDecisionEngineService.getcreditScore(creditReq());
		Assert.assertNotNull(creditScoreRes);

		CreditRequest crereq = creditReq();
		Response crescore = new Response();
		Mockito.when(creditDecisionEngineService.getcreditScore(crereq)).thenReturn(crescore);
		// Assert.assertEquals(700, crescore.getSanctionAmount());
		Assert.assertEquals("ssn01", crescore.getSsnNumber());

		ResponseEntity<CreditScore> cs = restTemplate.getForEntity("http://localhost:8081/getCreditScore",
				CreditScore.class);
		Assert.assertNotNull(cs);
		when(restTemplate.getForObject(urlName, CreditScore.class)).thenReturn(new CreditScore());
		Assert.assertNotNull(crescore);
	}

	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();

		cs.setCreditScore("700");
		return cs;

	}
}
